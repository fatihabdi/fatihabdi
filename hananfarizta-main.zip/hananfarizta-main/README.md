<h1 align="center">Hi 👋, I'm Muhammad Hanan Rafif Farizta</h1>
<h3 align="center">An innovative tech mind and high interest in Front-end Development, Mobile Development, and UI/UX Design.</h3>
<div align="center">
<img src="https://media.giphy.com/media/RbDKaczqWovIugyJmW/giphy.gif">
</div>
<br>
<p align="center"> <a href="https://github.com/ryo-ma/github-profile-trophy"><img src="https://github-profile-trophy.vercel.app/?username=hananfarizta" alt="hananfarizta" /></a> </p>
<img src="https://media.giphy.com/media/o7f8rvkZIbtgKP93iq/giphy.gif" align="right">


- 🔭 I’m currently working on **Self employed(Looking for an Internship Opportunity)**

- 🌱 I’m currently learning **Flutter, Laravel, and Python**

- 💬 Ask me about **Anything**

- 📫 How to reach me **hananfarizta.business@gmail.com**

- 📄 Know about my experiences [https://s.id/PortoHanan](https://s.id/PortoHanan)

<br>
<h3>Connect with me:</h3>
<p>
<a href="https://twitter.com/hananfariztaa" target="blank"><img align="center" src="https://raw.githubusercontent.com/jmnote/z-icons/master/svg/twitter.svg" alt="hananfariztaa" height="30" width="40" /></a>
<a href="https://linkedin.com/in/hananfarizta" target="blank"><img align="center" src="https://img.icons8.com/fluency/344/linkedin-circled.png" alt="hananfarizta" height="40" width="40" /></a>
<a href="https://fb.com/hananfarizta" target="blank"><img align="center" src="https://raw.githubusercontent.com/jmnote/z-icons/master/svg/facebook.svg" alt="hananfarizta" height="30" width="40" /></a>
<a href="https://instagram.com/hananfarizta" target="blank"><img align="center" src="https://img.icons8.com/fluency/344/instagram-new.png" alt="hananfarizta" height="40" width="40" /></a>

<h3>Languages and Tools:</h3>
<p>
  <a href="https://dart.dev" target="_blank"> <img src="https://www.vectorlogo.zone/logos/dartlang/dartlang-icon.svg" alt="dart" width="40" height="40"/> </a> 
  <a href="https://www.figma.com/" target="_blank"> <img src="https://www.vectorlogo.zone/logos/figma/figma-icon.svg" alt="figma" width="40" height="40"/> </a> 
  <a href="https://firebase.google.com/" target="_blank"> <img src="https://www.vectorlogo.zone/logos/firebase/firebase-icon.svg" alt="firebase" width="40" height="40"/> </a> 
  <a href="https://flutter.dev" target="_blank"> <img src="https://www.vectorlogo.zone/logos/flutterio/flutterio-icon.svg" alt="flutter" width="40" height="40"/> </a> 
  <a href="https://www.w3.org/html/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> </a> 
  <a href="https://www.w3schools.com/css/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="40" height="40"/> </a> 
  <a href="https://www.mysql.com/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg" alt="mysql" width="40" height="40"/> </a> 
  <a href="https://www.php.net" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/php/php-original.svg" alt="php" width="40" height="40"/> </a> 
  <a href="https://www.python.org" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a>
  <a href="https://www.python.org](https://laravel.com/" target="_blank"> <img src="https://laravel.com/img/logomark.min.svg" alt="laravel" width="40" height="40"/> </a>
</p>
<br>
<div align="center">
<p><img align="center" src="https://github-readme-stats.vercel.app/api/top-langs?username=hananfarizta&show_icons=true&locale=en&layout=compact" alt="hananfarizta" /></p>
<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=hananfarizta&show_icons=true&locale=en" alt="hananfarizta" /></p>
<p><img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=hananfarizta&" alt="hananfarizta" /></p>
<h1 align="center">【T】【H】【A】【N】【K】 【Y】【O】【U】【!】</h1>
<div align="center">
<img src="https://media.giphy.com/media/3oz8xIsloV7zOmt81G/giphy.gif">
</div>
</div>
